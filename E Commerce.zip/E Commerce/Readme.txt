FrontEND 
-------------------------------------------
1.node version 14.17.3
2.install angularCLI as 6.0.8
3.Cd to angular file
4.npm install
5.ng serve -o

STS
--------------------------------------------

1. Java JRE should be 14 version
2. application properities - need to change DB credentials 

DB
---------------------------------------------

1. authorities - need to create ROLE_ADMIN then only admin can login